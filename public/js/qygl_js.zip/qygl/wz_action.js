// JavaScript Document
(function(){
	var DB = KF_GRID_ACTIONS.qygl;
	
	DB.wz = function(grid){
		$table.supr.call(this, grid);
	};

	var $table = DB.wz;
	XT.extend($table, gc_grid_action);

	$table.prototype.contextActions = function(action, el){
// tool.debug(action);
		return $table.supr.prototype.contextActions.call(this, action, el);
	};
	
	$table.prototype.information_open = function(divId, element_id, pageName){
		pageName = pageName || 'all';
		$table.supr.prototype.information_open.call(this, divId, element_id, pageName);
		var hidefields = function(){
			var wz_fl_id = parseInt($('#' + divId + ' #wz_fl_id').val()), hide_fields = [], disp_fields = [];
			var zuhe = parseInt($('#' + divId + ' #zuhe').val());
		// $this->options['edit'] = array('wz_fl_id', 'name', 'unit_fl_id'=>array('label'=>'计量单位类型'), 
			// 'unit_id', 'default_price', 
			// 'min_kc', 'max_kc', 'pd_days', 'pd_last', 'jy_days', 'wh_days',
			// 'midu', 'tj', 'bmj', 'zuhe', 'wz_cp_zuhe', 'jszb_wz', 'gys_id', 'kh_id', 'pic', 'note', 'isactive'
		// );
			switch(wz_fl_id){
				case 0: //没有选中
					hide_fields = ['price1', 'min_kc1', 'max_kc1', 'ck_weizhi_id1', 'remained1', 'pd_days1', 'pd_last', 'jy_days', 'wh_days', 
						'midu', 'tj', 'bmj', 'zuhe', 'wz_cp_zuhe', 'jszb_wz', 'gx_wz', 'muju', 'wz_sb', 'gys_id', 'kh_id', 'pic'];
					break;
				case 3: //产品
					disp_fields = ['jy_days', 'tj', 'bmj', 'zuhe', 'jszb_wz', 'gx_wz', 'kh_id', 'pic'];
					hide_fields = ['wz_sb', 'price1', 'min_kc1', 'max_kc1', 'ck_weizhi_id1', 'remained1', 'pd_days1', 'midu', 'wh_days', 'gys_id'];
					if(zuhe == 2){
						disp_fields.push('wz_cp_zuhe');
						hide_fields.push('muju');
					}
					else{
						disp_fields.push('muju');
						hide_fields.push('wz_cp_zuhe');
					}
					break;
				case 2: //设备
					disp_fields = ['wz_sb', 'price1', 'min_kc1', 'max_kc1', 'ck_weizhi_id1', 'remained1', 'pd_days1', 'pd_last', 'wh_days', 'gys_id'];
					hide_fields = ['gx_wz', 'midu', 'tj', 'bmj', 'zuhe', 'wz_cp_zuhe', 'jszb_wz', 'muju', 'jy_days', 'kh_id'];
					break;
				case 7: //维修用品
					disp_fields = ['price1', 'min_kc1', 'max_kc1', 'ck_weizhi_id1', 'remained1', 'pd_days1', 'pd_last', 'wh_days', 'gys_id'];
					hide_fields = ['gx_wz', 'midu', 'tj', 'bmj', 'zuhe', 'wz_cp_zuhe', 'jszb_wz', 'muju', 'wz_sb', 'jy_days', 'kh_id'];
					break;
				case 4: //服务
				case 8: //能源
					hide_fields = ['midu', 'tj', 'bmj', 'zuhe', 'wz_cp_zuhe', 'wh_days', 'kh_id', 
						'jszb_wz', 'gx_wz', 'pd_last', 'jy_days', 'muju', 'wz_sb', 'wh_days', 'pic', 'min_kc1', 'max_kc1', 'ck_weizhi_id1', 'remained1', 'pd_days1'];
					disp_fields = ['price1', 'gys_id'];
					break;
				case 5: //劳保用品
				case 6: //办公用品
					hide_fields = ['midu', 'tj', 'bmj', 'zuhe', 'wz_cp_zuhe', 'jszb_wz', 'gx_wz', 'muju', 'wz_sb', 'wh_days', 'kh_id'];
					disp_fields = ['price1', 'min_kc1', 'max_kc1', 'ck_weizhi_id1', 'remained1', 'pd_days1', 'pd_last', 'jy_days', 'gys_id'];
					break;
				case 1: //原材料
				case 9: // 其他
				default:
					hide_fields = ['tj', 'bmj', 'zuhe', 'wz_cp_zuhe', 'jszb_wz', 'muju', 'wz_sb', 'wh_days', 'kh_id', 'gx_wz'];
					disp_fields = ['price1', 'min_kc1', 'max_kc1', 'ck_weizhi_id1', 'remained1', 'pd_days1', 'pd_last', 'jy_days', 'midu', 'gys_id'];
					break;
			}
			for(var i in disp_fields){
				$('#' + divId + ' #ces_tr_' + disp_fields[i]).show();
			}
			for(var i in hide_fields){
				$('#' + divId + ' #ces_tr_' + hide_fields[i]).hide();
			}
		};
		hidefields();
		//事件绑定
		//根据物资类型隐藏一些fields
		$('#' + divId + ' #wz_fl_id').unbind('change').bind('change', function(){
			hidefields();
		});
		//根据是否组合产品决定是否显示详细组合信息
		$('#' + divId + ' input[name="zuhe"]').unbind('change').bind('change', function(){
			var zuhe = parseInt($('#' + divId + ' input[name="zuhe"]:checked').val());
// tool.debug(zuhe);			
			if(zuhe == 2){
				$('#' + divId + ' #ces_tr_wz_cp_zuhe').show();
			}
			else
				$('#' + divId + ' #ces_tr_wz_cp_zuhe').hide();
		});
		
		//单位类型绑定单位
		var target = [
			{
				selector:'#' + divId + ' #unit_id', 
				type:'select', 
				field:'unit_fl_id', 
				url:'/jqgrid/jqgrid/oper/linkage/db/qygl/table/unit'
			},
		];
		XT.linkage({selector:'#' + divId + ' #unit_fl_id'}, target);
		
		$('#' + divId  + ' #unit_id').unbind('change').bind('change', function(){
			var unit = $(this).find("option:selected").text(), post = ['min_kc1', 'max_kc1', 'remained1', 'min_kc', 'max_kc', 'remained'];
			for(var i in post){
				$('#' + divId + ' #' + post[i] + '_post').html(unit);
			}
		});
	};
	
	$table.prototype.getGridsForInfo = function(divId){
		var grids = [
			{tab:'genzong', container:'genzong', table:'yw', params:{real_table:'yw', from:'wz'}},
		];
		return grids;
	};
	
	
}());
