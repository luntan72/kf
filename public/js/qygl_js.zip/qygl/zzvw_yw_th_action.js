// JavaScript Document
(function(){
	var DB = KF_GRID_ACTIONS.qygl;
	var tool = new kf_tool();
	DB.zzvw_yw_th = function(grid){
		$table.supr.call(this, grid);
	};

	var $table = DB.zzvw_yw_th;
	tool.extend($table, gc_grid_action);

	$table.prototype.information_open = function(divId, element_id, pageName, display_status){
		var $this = this;
		pageName = pageName || 'all';
		$table.supr.prototype.information_open.call(this, divId, element_id, pageName, display_status);
		if(display_status != 1) // NOT VIEW
			eventsBindForTH(divId, this, false);
	};
	
	var eventsBindForTH = function(divId, context, first){ //订单类事件绑定
		//交易方和物资之间绑定
		var prefix = 'zzvw_yw_th_detail', temp = '#' + divId + ' #' + prefix + '_temp';
		target = [
			{
				selector:temp + ' #dingdan_id', 
				type:'select', 
				field:'dingdan_id', 
				url:'/jqgrid/jqgrid/oper/get_executing_dingdan_by_hb/db/qygl/table/dingdan/yw_fl_id/1/status/1' //正在执行中的订单
			}
		];
		tool.linkage({selector:temp + ' #hb_id'}, target);
		//订单和计量单位及默认单价绑定
		$(temp + ' #dingdan_id').unbind('change').bind('change', function(event){
			var option = $(this).find("option:selected"), unit_name = option.attr('unit_name'), wz_id = option.attr('wz_id'), 
				dingdan_amount = option.attr('amount'), dingdan_completed = option.attr('completed_amount'), 
				dingdan_remained = dingdan_amount - dingdan_completed;
// tool.debug([default_price, unit_name, remained, temp]);
			$(temp + ' #amount_post,#dingdan_amount_post,#pici_remained_post,#dingdan_remained_post').html(unit_name);
			$(temp + ' #wz_id').val(wz_id);
			$(temp + ' #dingdan_amount').val(dingdan_amount);
			$(temp + ' #dingdan_remained').val(dingdan_remained);
			//获取批次信息
			$.post('/jqgrid/jqgrid/db/qygl/table/zzvw_pici_sh/oper/get_pici_by_dingdan', {dingdan_id:$(this).val()}, function(data){
				$(temp + ' #pici_id').find('option').remove();
				tool.generateOptions($(temp + ' #pici_id'), data, 'id', 'name', true);
			}, 'json');
		});
		
		$(temp + ' #pici_id').unbind('change').bind('change', function(event){
			var option = $(this).find("option:selected"), pici_remained = option.attr('remained');
// tool.debug([pici_remained, temp]);
			if(pici_remained != undefined){
				$(temp + ' #pici_remained').val(pici_remained);
				$(temp + ' #amount').attr('max', pici_remained);
			}
			else{
				$(temp + ' #pici_remained').val(0);
				$(temp + ' #amount').removeAttr('max');
			}
		});
		
		//数量、单价和总价之间绑定
		var auto_generate_total = function(){
			var $source = [temp + ' #amount', temp + ' #price'];
			var $dest = temp + ' #total_money';
			tool.auto_fill_calc_result($dest, $source, '*', 2);
		}
		// $(temp + ' #amount').bind('keyup', auto_generate_total);
		// $(temp + ' #price').bind('keyup', auto_generate_total);
	};
}());
