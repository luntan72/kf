qygl.ck = {
	create: function(){
		var ck = gc_grid.create('qygl', 'ck');
		ck.hello = function(){alert("just a test");};
		return ck;
	}
};